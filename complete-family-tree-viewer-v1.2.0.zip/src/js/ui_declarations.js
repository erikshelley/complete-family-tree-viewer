// Page Element Variables
const optionsMenu = document.getElementById('options-menu-button');

const file_name_span = document.getElementById('file-name');
const save_filename_input = document.getElementById('save-filename-input');
const save_modal = document.getElementById('save-modal');
const save_modal_ok_button = document.getElementById('save-modal-ok-button');
const save_modal_cancel_button = document.getElementById('save-modal-cancel-button');
const open_online_button = document.getElementById('open-online-button');
const online_gedcom_modal = document.getElementById('online-gedcom-modal');
const online_gedcom_cancel_button = document.getElementById('online-gedcom-cancel-button');

const leftColumnWrapper = document.querySelector('.left-column-wrapper');
const leftCol = document.querySelector('.left-column');
const file_input = document.getElementById('file-input-button');
const individual_filter = document.getElementById('individual-filter-text');
const clearIndividualFilterbutton = document.getElementById('clear-individual-filter');
const individual_select = document.getElementById('individual-select');

const preset_select = document.getElementById('preset-select');

const hue_element = document.getElementById('hue-range');
const sat_element = document.getElementById('saturation-range');
const lum_element = document.getElementById('node-brightness-range');
const text_lum_element = document.getElementById('text-brightness-range');
const root_name = document.getElementById('root-name');
const generations_up_number = document.getElementById('generations-up-number');
const generations_down_number = document.getElementById('generations-down-number');
const max_stack_size_number = document.getElementById('max-stack-size-number');

const color_picker = document.getElementById('color-picker');

const rightCol = document.querySelector('.right-column');
const family_tree_div = document.getElementById('family-tree-div');
const resize_tree_button = document.getElementById('resize-tree-button');
const resize_tree_horizontal_button = document.getElementById('resize-tree-horizontal-button');
const resize_tree_vertical_button = document.getElementById('resize-tree-vertical-button');
const expand_styling_button = document.getElementById('expand-styling-button');
const collapse_styling_button = document.getElementById('collapse-styling-button');
const save_tree_button = document.getElementById('save-tree-button');

let filter_timeout = null;
let update_in_progress = false;
let update_waiting = false;
let update_timeout = null;

// Tree Content Variables
window.individual_filter_value = '';
window.selected_individual = '';
window.generations_up;
window.generations_down;
window.max_stack_size;
window.hide_childless_inlaws;
window.hide_non_pedigree_family;

// Tree Styling Variables
window.box_width; window.default_box_width;
window.box_height; window.default_box_height;
window.h_spacing; window.default_h_spacing;
window.v_spacing; window.default_v_spacing;
window.node_rounding; window.default_node_rounding;
window.node_brightness; window.default_node_brightness;
window.vertical_inlaws; window.default_vertical_inlaws;
window.show_names; window.default_show_names;
window.show_years; window.default_show_years;
window.show_places; window.default_show_places;

window.node_border_width; window.default_node_border_width;
window.border_highlight_percent; window.default_border_highlight_percent;

window.level_spacing; window.default_level_spacing;
window.tree_padding; window.default_tree_padding;

window.link_width; window.default_link_width;
window.link_rounding; window.default_link_rounding;
window.link_highlight_percent; window.default_link_highlight_percent;
window.inlaw_link_highlight_percent; window.default_inlaw_link_highlight_percent;

window.pedigree_highlight_percent; window.default_pedigree_highlight_percent;

window.text_size; window.default_text_size;
window.text_brightness; window.default_text_brightness;
window.text_shadow; window.default_text_shadow;
window.root_hue; window.default_node_hue;
window.node_saturation; window.default_node_saturation;
window.transparent_bg_rect; window.default_transparent_bg_rect;

window.tree_color = color_picker.value;

const style_presets = {
    'traditional': {
        // Content
        'max-stack-size': 1, 'vertical-inlaws': false, 'show-names': true, 'show-years': true, 'show-places': false,
        // Size
        'node-width': 48, 'node-height': 48, 'node-border-width': 1, 'link-width': 2, 'text-size': 8,
        // Spacing
        'h-spacing': 12, 'v-spacing': 24, 'level-spacing': 12, 'box-padding': 4, 'tree-padding': 12, 'text-align': 'top',
        // Color
        'hue': 180, 'saturation': 20, 'node-brightness': 30, 'text-brightness': 80, 'text-shadow': false, 'transparent-bg-rect': false, 'background-color': '#000000',
        // Highlights
        'pedigree-highlight-percent': 100, 'border-highlight-percent': 125, 'link-highlight-percent': 125, 'inlaw-link-highlight-percent': 125,
        // Rounding
        'node-rounding': 10, 'link-rounding': 10,
    },
    'balanced': {
        // Content
        'max-stack-size': 2, 'vertical-inlaws': true, 'show-names': true, 'show-years': true, 'show-places': false,
        // Size
        'node-width': 75, 'node-height': 50, 'node-border-width': 2, 'link-width': 4, 'text-size': 12,
        // Spacing
        'h-spacing': 25, 'v-spacing': 50, 'level-spacing': 100, 'box-padding': 2, 'tree-padding': 100, 'text-align': 'top',
        // Color
        'hue': 180, 'saturation': 20, 'node-brightness': 25, 'text-brightness': 80, 'text-shadow': true, 'transparent-bg-rect': false, 'background-color': '#000000',
        // Highlights
        'pedigree-highlight-percent': 150, 'border-highlight-percent': 125, 'link-highlight-percent': 125, 'inlaw-link-highlight-percent': 150,
        // Rounding
        'node-rounding': 25, 'link-rounding': 25,
    },
    'stacked': {
        // Content
        'max-stack-size': 99, 'vertical-inlaws': true, 'show-names': true, 'show-years': false, 'show-places': false,
        // Size
        'node-width': 75, 'node-height': 50, 'node-border-width': 2, 'link-width': 4, 'text-size': 12,
        // Spacing
        'h-spacing': 25, 'v-spacing': 25, 'level-spacing': 50, 'box-padding': 2, 'tree-padding': 100, 'text-align': 'middle',
        // Color
        'hue': 180, 'saturation': 20, 'node-brightness': 30, 'text-brightness': 80, 'text-shadow': false, 'transparent-bg-rect': false, 'background-color': '#000000',
        // Highlights
        'pedigree-highlight-percent': 100, 'border-highlight-percent': 125, 'link-highlight-percent': 125, 'inlaw-link-highlight-percent': 125,
        // Rounding
        'node-rounding': 25, 'link-rounding': 25,
    },
    'detailed': {
        // Content
        'max-stack-size': 1, 'vertical-inlaws': false, 'show-names': true, 'show-years': true, 'show-places': true,
        // Size
        'node-width': 150, 'node-height': 150, 'node-border-width': 5, 'link-width': 5, 'text-size': 16,
        // Spacing
        'h-spacing': 25, 'v-spacing': 50, 'level-spacing': 50, 'box-padding': 10, 'tree-padding': 100, 'text-align': 'top',
        // Color
        'hue': 180, 'saturation': 20, 'node-brightness': 30, 'text-brightness': 80, 'text-shadow': true, 'transparent-bg-rect': false, 'background-color': '#000000',
        // Highlights
        'pedigree-highlight-percent': 100, 'border-highlight-percent': 125, 'link-highlight-percent': 125, 'inlaw-link-highlight-percent': 125,
        // Rounding
        'node-rounding': 10, 'link-rounding': 25,
    },
    'print': {
        // Content
        'max-stack-size': 1, 'vertical-inlaws': false, 'show-names': true, 'show-years': true, 'show-places': false,
        // Size
        'node-width': 150, 'node-height': 150, 'node-border-width': 5, 'link-width': 10, 'text-size': 24,
        // Spacing
        'h-spacing': 50, 'v-spacing': 100, 'level-spacing': 100, 'box-padding': 2, 'tree-padding': 150, 'text-align': 'middle',
        // Color
        'hue': 300, 'saturation': 20, 'node-brightness': 80, 'text-brightness': 40, 'text-shadow': false, 'transparent-bg-rect': false, 'background-color': '#ffffff',
        // Highlights
        'pedigree-highlight-percent': 100, 'border-highlight-percent': 90, 'link-highlight-percent': 90, 'inlaw-link-highlight-percent': 90,
        // Rounding
        'node-rounding': 25, 'link-rounding': 50,
    },
    'sharp': {
        // Content
        'max-stack-size': 1, 'vertical-inlaws': true, 'show-names': true, 'show-years': true, 'show-places': false,
        // Size
        'node-width': 100, 'node-height': 100, 'node-border-width': 3, 'link-width': 6, 'text-size': 16,
        // Spacing
        'h-spacing': 50, 'v-spacing': 75, 'level-spacing': 100, 'box-padding': 10, 'tree-padding': 150, 'text-align': 'top',
        // Color
        'hue': 180, 'saturation': 20, 'node-brightness': 25, 'text-brightness': 80, 'text-shadow': true, 'transparent-bg-rect': false, 'background-color': '#000000',
        // Highlights
        'pedigree-highlight-percent': 150, 'border-highlight-percent': 125, 'link-highlight-percent': 125, 'inlaw-link-highlight-percent': 150,
        // Rounding
        'node-rounding': 0, 'link-rounding': 0,
    },
    'orbs': {
        // Content
        'max-stack-size': 99, 'vertical-inlaws': true, 'show-names': true, 'show-years': false, 'show-places': false,
        // Size
        'node-width': 100, 'node-height': 100, 'node-border-width': 5, 'link-width': 5, 'text-size': 16,
        // Spacing
        'h-spacing': 25, 'v-spacing': 50, 'level-spacing': 100, 'box-padding': 10, 'tree-padding': 150, 'text-align': 'middle',
        // Color
        'hue': 180, 'saturation': 20, 'node-brightness': 30, 'text-brightness': 80, 'text-shadow': true, 'transparent-bg-rect': false, 'background-color': '#000000',
        // Highlights
        'pedigree-highlight-percent': 150, 'border-highlight-percent': 125, 'link-highlight-percent': 125, 'inlaw-link-highlight-percent': 150,
        // Rounding
        'node-rounding': 50, 'link-rounding': 50,
    },
}

const elements = [
    // Tree Content
    { id: 'generations-up-number',               type: 'number',   default: 1,     min: 0, max: 99, variable: 'generations_up' },
    { id: 'generations-down-number',             type: 'number',   default: 1,     min: 0, max: 99, variable: 'generations_down' },
    { id: 'max-stack-size-number',               type: 'number',   default: 2,     min: 1, max: 99, variable: 'max_stack_size' },
    { id: 'show-names-checkbox',                 type: 'checkbox', default: true,  variable: 'show_names' },
    { id: 'show-years-checkbox',                 type: 'checkbox', default: true,  variable: 'show_years' },
    { id: 'show-places-checkbox',                type: 'checkbox', default: false, variable: 'show_places' },
    { id: 'vertical-inlaws-checkbox',            type: 'checkbox', default: true,  variable: 'vertical_inlaws' },
    { id: 'hide-childless-inlaws-checkbox',      type: 'checkbox', default: false, variable: 'hide_childless_inlaws' },
    { id: 'hide-non-pedigree-family-checkbox',   type: 'checkbox', default: false, variable: 'hide_non_pedigree_family' },

    // Tree Styling
    // Size
    { id: 'node-width-number',                   type: 'number',   default: 100,   min: 20, max: 480, variable: 'box_width' },
    { id: 'node-width-range',                    type: 'range',    default: 100,   min: 20, max: 480, variable: 'box_width' },
    { id: 'node-height-number',                  type: 'number',   default: 100,    min: 20, max: 480, variable: 'box_height' },
    { id: 'node-height-range',                   type: 'range',    default: 100,    min: 20, max: 480, variable: 'box_height' },
    { id: 'node-border-width-number',            type: 'number',   default: 3,     min: 0, max: 20, variable: 'node_border_width' },
    { id: 'node-border-width-range',             type: 'range',    default: 3,     min: 0, max: 20, variable: 'node_border_width' },
    { id: 'link-width-number',                   type: 'number',   default: 6,     min: 1, max: 20, variable: 'link_width' },
    { id: 'link-width-range',                    type: 'range',    default: 6,     min: 1, max: 20, variable: 'link_width' },
    { id: 'text-size-number',                    type: 'number',   default: 16,    min: 1, max: 100, variable: 'text_size' },
    { id: 'text-size-range',                     type: 'range',    default: 16,    min: 1, max: 100, variable: 'text_size' },

    // Spacing
    { id: 'h-spacing-number',                    type: 'number',   default: 50,    min: 0, max: 480, variable: 'h_spacing' },
    { id: 'h-spacing-range',                     type: 'range',    default: 50,    min: 0, max: 480, variable: 'h_spacing' },
    { id: 'v-spacing-number',                    type: 'number',   default: 50,    min: 0, max: 480, variable: 'v_spacing' },
    { id: 'v-spacing-range',                     type: 'range',    default: 50,    min: 0, max: 480, variable: 'v_spacing' },
    { id: 'level-spacing-number',                type: 'number',   default: 100,   min: 0, max: 400, variable: 'level_spacing' },
    { id: 'level-spacing-range',                 type: 'range',    default: 100,   min: 0, max: 400, variable: 'level_spacing' },
    { id: 'box-padding-number',                  type: 'number',   default: 2,     min: 0, max: 50, variable: 'box_padding' },
    { id: 'box-padding-range',                   type: 'range',    default: 2,     min: 0, max: 50, variable: 'box_padding' },
    { id: 'tree-padding-number',                 type: 'number',   default: 150,   min: 0, max: 600, variable: 'tree_padding' },
    { id: 'tree-padding-range',                  type: 'range',    default: 150,   min: 0, max: 600, variable: 'tree_padding' },
    { id: 'text-align-select',                   type: 'select',   default: 'middle', variable: 'text_align' },

    // Color
    { id: 'hue-number',                          type: 'number',   default: 180,   min: 0, max: 360, variable: 'root_hue' },
    { id: 'hue-range',                           type: 'range',    default: 180,   min: 0, max: 360, variable: 'root_hue' },
    { id: 'saturation-number',                   type: 'number',   default: 20,    min: 0, max: 100, variable: 'node_saturation' },
    { id: 'saturation-range',                    type: 'range',    default: 20,    min: 0, max: 100, variable: 'node_saturation' },
    { id: 'node-brightness-number',              type: 'number',   default: 30,    min: 0, max: 100, variable: 'node_brightness' },
    { id: 'node-brightness-range',               type: 'range',    default: 30,    min: 0, max: 100, variable: 'node_brightness' },
    { id: 'text-brightness-number',              type: 'number',   default: 80,    min: 0, max: 100, variable: 'text_brightness' },
    { id: 'text-brightness-range',               type: 'range',    default: 80,    min: 0, max: 100, variable: 'text_brightness' },
    { id: 'text-shadow-checkbox',                type: 'checkbox', default: true,  variable: 'text_shadow' },
    { id: 'transparent-bg-rect-checkbox',        type: 'checkbox', default: false, variable: 'transparent_bg_rect' },

    // Highlights
    { id: 'pedigree-highlight-percent-number',   type: 'number',   default: 175,   min: 0, max: 200, variable: 'pedigree_highlight_percent' },
    { id: 'pedigree-highlight-percent-range',    type: 'range',    default: 175,   min: 0, max: 200, variable: 'pedigree_highlight_percent' },
    { id: 'border-highlight-percent-number',     type: 'number',   default: 125,   min: 0, max: 200, variable: 'border_highlight_percent' },
    { id: 'border-highlight-percent-range',      type: 'range',    default: 125,   min: 0, max: 200, variable: 'border_highlight_percent' },
    { id: 'link-highlight-percent-number',       type: 'number',   default: 125,   min: 0, max: 200, variable: 'link_highlight_percent' },
    { id: 'link-highlight-percent-range',        type: 'range',    default: 125,   min: 0, max: 200, variable: 'link_highlight_percent' },
    { id: 'inlaw-link-highlight-percent-number', type: 'number',   default: 150,   min: 0, max: 200, variable: 'inlaw_link_highlight_percent' },
    { id: 'inlaw-link-highlight-percent-range',  type: 'range',    default: 150,   min: 0, max: 200, variable: 'inlaw_link_highlight_percent' },

    // Rounding
    { id: 'node-rounding-number',                type: 'number',   default: 25,    min: 0, max: 100, variable: 'node_rounding' },
    { id: 'node-rounding-range',                 type: 'range',    default: 25,    min: 0, max: 100, variable: 'node_rounding' },
    { id: 'link-rounding-number',                type: 'number',   default: 25,    min: 0, max: 100, variable: 'link_rounding' },
    { id: 'link-rounding-range',                 type: 'range',    default: 25,    min: 0, max: 100, variable: 'link_rounding' },
];

const none_links = [
    { id: 'no-border-highlight-percent', variable: 'border_highlight_percent' },
    { id: 'no-pedigree-highlight-percent', variable: 'pedigree_highlight_percent' },
    { id: 'no-link-highlight-percent', variable: 'link_highlight_percent' },
    { id: 'no-inlaw-link-highlight-percent', variable: 'inlaw_link_highlight_percent' },
]

const auto_links = [
    { id: 'auto-node-width', variable: 'box_width' },
    { id: 'auto-node-height', variable: 'box_height' },
]
